<!DOCTYPE html>

<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="robots" content="noindex, follow">
		<title>Page Not Found (404)</title>
		<link rel="stylesheet" href="/typo3/sysext/core/Resources/Public/Css/errorpage.css">
	</head>
	<body class="t3-message-page t3-errorpage-message">
		<div class="t3-error-wrap">
			<div class="t3-message-page-container">
				<div class="t3-message-page-logo">
					<img src="/typo3/sysext/backend/Resources/Public/Images/typo3_orange.svg" class="typo3-error-image" alt="TYPO3 logo">
				</div>
				<div class="callout callout-danger">
					<div class="media">
						<div class="media-left">
							<span class="fa-stack fa-lg callout-icon">
								<i class="fa fa-circle fa-stack-2x"></i>
								<i class="fa fa-exclamation-triangle fa-stack-1x"></i>
							</span>
						</div>
						<div class="media-body">
							<h4 class="alert-title">Page Not Found (404)</h4>
							<div class="callout-body">
								The requested page does not exist
								
									<p>More information regarding this error might be available <a href="https://typo3.org/go/exception/CMS/1518472189" target="_blank">online</a>.</p>
								
							</div>
						</div>
					</div>
				</div>
				<div id="t3-footer">
					<div id="t3-copyright-notice">
						TYPO3 is an open source content management system. To maintain the quality of the system and to improve it, please help us by
						donating.
						Copyright &copy; 1998-2026 Kasper Skårhøj. Extensions are copyright of their respective owners. Go to
						<a href="https://typo3.org/">https://typo3.org/</a> for details.
						TYPO3 CMS comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to redistribute it under certain conditions.
						Obstructing the appearance of this notice is prohibited by law.
					</div>
				</div>
			</div>
		</div>
	</body>


